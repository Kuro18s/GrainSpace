import { FormEvent, useEffect, useMemo, useState } from "react";

const photos = [
  "https://images.unsplash.com/photo-1698899114653-bcb1168c3123?auto=format&fit=crop&w=1200&q=85",
  "https://images.unsplash.com/photo-1698899114691-3e4a5d9be3dc?auto=format&fit=crop&w=900&q=85",
  "https://images.unsplash.com/photo-1698899114761-3a154520c816?auto=format&fit=crop&w=900&q=85",
];

const spaces = [
  { name: "Saigon Darkroom 36", place: "Quận 3, TP. Hồ Chí Minh", type: "Phòng tối", price: 180, rating: 4.9, image: photos[0], badge: "Được yêu thích" },
  { name: "The Grain Studio", place: "Quận 1, TP. Hồ Chí Minh", type: "Studio", price: 350, rating: 4.8, image: photos[1], badge: "Còn lịch hôm nay" },
  { name: "Noir Film Lab", place: "Ba Đình, Hà Nội", type: "Phòng tối", price: 220, rating: 4.7, image: photos[2], badge: "Phản hồi nhanh" },
];

type Role = "customer" | "admin";

type AuthUser = {
  name: string;
  email: string;
  role: Role;
};

const demoAccounts: Record<Role, AuthUser & { password: string }> = {
  customer: {
    name: "An Nguyễn",
    email: "khachhang@filmlab.vn",
    password: "123456",
    role: "customer",
  },
  admin: {
    name: "Quản trị viên",
    email: "admin@filmlab.vn",
    password: "123456",
    role: "admin",
  },
};

function Icon({ name, size = 20 }: { name: string; size?: number }) {
  const paths: Record<string, React.ReactNode> = {
    compass: <><circle cx="12" cy="12" r="9"/><path d="m15.5 8.5-2 5-5 2 2-5 5-2Z"/></>,
    calendar: <><rect x="3" y="5" width="18" height="16" rx="2"/><path d="M16 3v4M8 3v4M3 10h18"/></>,
    users: <><path d="M16 21v-2a4 4 0 0 0-4-4H6a4 4 0 0 0-4 4v2"/><circle cx="9" cy="7" r="4"/><path d="M19 8v6M22 11h-6"/></>,
    image: <><rect x="3" y="3" width="18" height="18" rx="2"/><circle cx="8.5" cy="8.5" r="1.5"/><path d="m21 15-5-5L5 21"/></>,
    search: <><circle cx="11" cy="11" r="7"/><path d="m20 20-4-4"/></>,
    map: <><path d="M20 10c0 5-8 11-8 11S4 15 4 10a8 8 0 1 1 16 0Z"/><circle cx="12" cy="10" r="2.5"/></>,
    star: <path d="m12 2.5 2.9 5.9 6.5.9-4.7 4.6 1.1 6.5-5.8-3.1-5.8 3.1 1.1-6.5-4.7-4.6 6.5-.9L12 2.5Z"/>,
    arrow: <><path d="M5 12h14M14 7l5 5-5 5"/></>,
    spark: <path d="m12 3 1.4 4.1L17.5 8.5l-4.1 1.4L12 14l-1.4-4.1-4.1-1.4 4.1-1.4L12 3Zm6 10 .8 2.2L21 16l-2.2.8L18 19l-.8-2.2L15 16l2.2-.8L18 13Z"/>,
    clock: <><circle cx="12" cy="12" r="9"/><path d="M12 7v5l3 2"/></>,
    camera: <><path d="M14.5 5 13 3h-2L9.5 5H5a2 2 0 0 0-2 2v11a2 2 0 0 0 2 2h14a2 2 0 0 0 2-2V7a2 2 0 0 0-2-2Z"/><circle cx="12" cy="12.5" r="4"/></>,
    close: <path d="m6 6 12 12M18 6 6 18"/>,
    user: <><circle cx="12" cy="8" r="4"/><path d="M4 21a8 8 0 0 1 16 0"/></>,
    lock: <><rect x="4" y="10" width="16" height="11" rx="2"/><path d="M8 10V7a4 4 0 0 1 8 0v3"/></>,
    eye: <><path d="M2.5 12s3.5-6 9.5-6 9.5 6 9.5 6-3.5 6-9.5 6-9.5-6-9.5-6Z"/><circle cx="12" cy="12" r="2.5"/></>,
    "eye-off": <><path d="m3 3 18 18M10.6 10.6a2 2 0 0 0 2.8 2.8M9.8 5.2A10.8 10.8 0 0 1 12 5c6 0 9.5 7 9.5 7a16 16 0 0 1-2 2.8M6.5 6.5C4 8.2 2.5 12 2.5 12s3.5 7 9.5 7a10 10 0 0 0 3.5-.6"/></>,
    logout: <><path d="M10 17l5-5-5-5M15 12H3"/><path d="M14 3h5a2 2 0 0 1 2 2v14a2 2 0 0 1-2 2h-5"/></>,
    shield: <path d="M12 22s8-4 8-10V5l-8-3-8 3v7c0 6 8 10 8 10Z"/>,
    grid: <><rect x="3" y="3" width="7" height="7"/><rect x="14" y="3" width="7" height="7"/><rect x="3" y="14" width="7" height="7"/><rect x="14" y="14" width="7" height="7"/></>,
    building: <><path d="M4 21V5l8-3 8 3v16M9 9h1M14 9h1M9 13h1M14 13h1M9 17h1M14 17h1M2 21h20"/></>,
    tool: <><path d="M14.7 6.3a4 4 0 0 0-5-5L12 3.6 9.6 6 7.3 3.7a4 4 0 0 0 5 5L4 17l3 3 7.7-8.3a4 4 0 0 0 0-5.4Z"/></>,
    chart: <><path d="M3 3v18h18"/><path d="m7 16 4-5 3 3 5-7"/></>,
    report: <><path d="M14 2H6a2 2 0 0 0-2 2v16a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2V8Z"/><path d="M14 2v6h6M8 13h8M8 17h6"/></>,
    plus: <path d="M12 5v14M5 12h14"/>,
    send: <path d="m22 2-7 20-4-9-9-4 20-7Z"/>,
    message: <><path d="M21 15a4 4 0 0 1-4 4H8l-5 3V7a4 4 0 0 1 4-4h10a4 4 0 0 1 4 4Z"/><path d="M8 9h8M8 13h5"/></>,
    upload: <><path d="M12 16V4M7 9l5-5 5 5"/><path d="M5 20h14"/></>,
    download: <><path d="M12 4v12M7 11l5 5 5-5"/><path d="M5 20h14"/></>,
    wand: <><path d="m15 4 5 5L7 22l-5-5L15 4Z"/><path d="m14 5 5 5M6 4V2M3 5H1M5 3 3 1M19 17v-2M22 18h-2M21 16l-2-2"/></>,
    heart: <path d="M20.8 4.6a5.5 5.5 0 0 0-7.8 0L12 5.7l-1.1-1.1a5.5 5.5 0 0 0-7.8 7.8l1.1 1.1L12 21l7.8-7.5 1.1-1.1a5.5 5.5 0 0 0-.1-7.8Z"/>,
    comment: <path d="M21 15a4 4 0 0 1-4 4H8l-5 3V7a4 4 0 0 1 4-4h10a4 4 0 0 1 4 4Z"/>,
    share: <><circle cx="18" cy="5" r="3"/><circle cx="6" cy="12" r="3"/><circle cx="18" cy="19" r="3"/><path d="m8.6 10.5 6.8-4M8.6 13.5l6.8 4"/></>,
    bookmark: <path d="M6 3h12v18l-6-4-6 4V3Z"/>,
    edit: <><path d="M12 20h9"/><path d="M16.5 3.5a2.1 2.1 0 0 1 3 3L8 18l-4 1 1-4Z"/></>,
    rotate: <><path d="M20 11a8 8 0 1 0-2.3 5.7"/><path d="M20 4v7h-7"/></>,
    flip: <><path d="M12 3v18M8 5 3 9v6l5 4V5ZM16 5l5 4v6l-5 4V5Z"/></>,
    reset: <><path d="M3 12a9 9 0 1 0 3-6.7"/><path d="M3 4v6h6"/></>,
  };
  return <svg width={size} height={size} viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.8" strokeLinecap="round" strokeLinejoin="round">{paths[name]}</svg>;
}

function LoginScreen({ onLogin }: { onLogin: (user: AuthUser) => void }) {
  const [authMode, setAuthMode] = useState<"login" | "register">("login");
  const [role, setRole] = useState<Role>("customer");
  const [email, setEmail] = useState(demoAccounts.customer.email);
  const [password, setPassword] = useState(demoAccounts.customer.password);
  const [name, setName] = useState("");
  const [phone, setPhone] = useState("");
  const [confirmPassword, setConfirmPassword] = useState("");
  const [acceptedTerms, setAcceptedTerms] = useState(false);
  const [showPassword, setShowPassword] = useState(false);
  const [error, setError] = useState("");

  const changeRole = (nextRole: Role) => {
    setRole(nextRole);
    setEmail(demoAccounts[nextRole].email);
    setPassword(demoAccounts[nextRole].password);
    setError("");
  };

  const handleSubmit = (event: FormEvent<HTMLFormElement>) => {
    event.preventDefault();
    if (authMode === "register") {
      if (name.trim().length < 2) {
        setError("Vui lòng nhập họ và tên của bạn.");
        return;
      }
      if (password.length < 6) {
        setError("Mật khẩu cần có ít nhất 6 ký tự.");
        return;
      }
      if (password !== confirmPassword) {
        setError("Mật khẩu xác nhận chưa trùng khớp.");
        return;
      }
      if (!acceptedTerms) {
        setError("Bạn cần đồng ý với điều khoản sử dụng.");
        return;
      }
      const newUser: AuthUser = { name: name.trim(), email: email.trim().toLowerCase(), role: "customer" };
      localStorage.setItem("filmlab-registered-account", JSON.stringify({ ...newUser, password, phone }));
      localStorage.setItem("filmlab-profile", JSON.stringify({
        name: newUser.name,
        email: newUser.email,
        phone,
        city: "",
        bio: "Thành viên mới của cộng đồng FilmLab.",
        preferences: [],
      }));
      onLogin(newUser);
      return;
    }
    const account = demoAccounts[role];
    const registered = loadAdminData<AuthUser & { password: string } | null>("filmlab-registered-account", null);
    const registeredMatches = role === "customer" && registered && email.trim().toLowerCase() === registered.email && password === registered.password;
    if (!registeredMatches && (email.trim().toLowerCase() !== account.email || password !== account.password)) {
      setError("Email hoặc mật khẩu không đúng với vai trò đã chọn.");
      return;
    }
    if (registeredMatches) {
      const { password: _password, ...registeredUser } = registered;
      onLogin(registeredUser);
      return;
    }
    const { password: _password, ...user } = account;
    onLogin(user);
  };

  const switchMode = (nextMode: "login" | "register") => {
    setAuthMode(nextMode);
    setError("");
    setShowPassword(false);
    if (nextMode === "register") {
      setRole("customer");
      setEmail("");
      setPassword("");
      setConfirmPassword("");
    } else {
      setEmail(demoAccounts.customer.email);
      setPassword(demoAccounts.customer.password);
    }
  };

  return (
    <main className="login-page">
      <section className="login-visual">
        <div className="login-brand">
          <span className="brand-mark"><Icon name="camera" size={19}/></span>
          <span>FILM<span>LAB</span></span>
        </div>
        <div className="login-quote">
          <span className="eyebrow"><span></span> CỘNG ĐỒNG NHIẾP ẢNH ANALOG</span>
          <h1>Mỗi cuộn film,<br/><em>một câu chuyện.</em></h1>
          <p>Khám phá không gian, kết nối cộng đồng và bắt đầu hành trình sáng tạo của bạn.</p>
        </div>
        <p className="photo-credit">Ảnh bởi NordWood Themes · Unsplash</p>
      </section>

      <section className="login-panel">
        <div className="login-form-wrap">
          <div className="mobile-login-brand">
            <span className="brand-mark"><Icon name="camera" size={18}/></span>
            <span>FILM<span>LAB</span></span>
          </div>
          <span className="kicker">CHÀO MỪNG TRỞ LẠI</span>
          <h2>{authMode === "login" ? "Đăng nhập vào FilmLab" : "Tạo tài khoản mới"}</h2>
          <p className="login-lead">{authMode === "login" ? "Chọn vai trò và sử dụng tài khoản mẫu để trải nghiệm nền tảng." : "Tham gia cộng đồng nhiếp ảnh analog và bắt đầu hành trình của bạn."}</p>

          {authMode === "login" && <div className="role-switch" role="tablist" aria-label="Chọn vai trò đăng nhập">
            <button type="button" role="tab" aria-selected={role === "customer"} className={role === "customer" ? "active" : ""} onClick={() => changeRole("customer")}>
              <Icon name="user" size={18}/>
              <span><b>Khách hàng</b><small>Khám phá & đặt lịch</small></span>
            </button>
            <button type="button" role="tab" aria-selected={role === "admin"} className={role === "admin" ? "active" : ""} onClick={() => changeRole("admin")}>
              <Icon name="shield" size={18}/>
              <span><b>Quản trị viên</b><small>Quản lý hệ thống</small></span>
            </button>
          </div>}

          <form className={`login-form ${authMode === "register" ? "register-form" : ""}`} onSubmit={handleSubmit}>
            {authMode === "register" && <div className="register-row">
              <label>
                <span>Họ và tên</span>
                <div className="field"><Icon name="user" size={18}/><input value={name} onChange={event => { setName(event.target.value); setError(""); }} placeholder="Nguyễn Minh Anh" autoComplete="name" required/></div>
              </label>
              <label>
                <span>Số điện thoại</span>
                <div className="field"><Icon name="users" size={18}/><input value={phone} onChange={event => setPhone(event.target.value)} placeholder="090 123 4567" autoComplete="tel" required/></div>
              </label>
            </div>}
            <label>
              <span>Email</span>
              <div className="field">
                <Icon name="user" size={18}/>
                <input type="email" value={email} onChange={event => { setEmail(event.target.value); setError(""); }} autoComplete="email" required/>
              </div>
            </label>
            <label>
              <span>Mật khẩu</span>
              <div className="field">
                <Icon name="lock" size={18}/>
                <input type={showPassword ? "text" : "password"} value={password} onChange={event => { setPassword(event.target.value); setError(""); }} autoComplete="current-password" required/>
                <button type="button" className="password-toggle" onClick={() => setShowPassword(value => !value)} aria-label={showPassword ? "Ẩn mật khẩu" : "Hiện mật khẩu"}>
                  <Icon name={showPassword ? "eye-off" : "eye"} size={18}/>
                </button>
              </div>
            </label>
            {authMode === "register" && <label>
              <span>Xác nhận mật khẩu</span>
              <div className="field">
                <Icon name="lock" size={18}/>
                <input type={showPassword ? "text" : "password"} value={confirmPassword} onChange={event => { setConfirmPassword(event.target.value); setError(""); }} autoComplete="new-password" required/>
              </div>
            </label>}
            {authMode === "login" ? <div className="login-options">
              <span>Tài khoản đã được điền sẵn</span>
              <button type="button" onClick={() => alert("Đây là bản đăng nhập giả lập. Tính năng khôi phục mật khẩu sẽ có khi kết nối backend.")}>Quên mật khẩu?</button>
            </div> : <label className="terms-check"><input type="checkbox" checked={acceptedTerms} onChange={event => { setAcceptedTerms(event.target.checked); setError(""); }}/><span>Tôi đồng ý với <button type="button" onClick={() => alert("Điều khoản sử dụng FilmLab phiên bản trải nghiệm.")}>Điều khoản sử dụng</button> và Chính sách bảo mật.</span></label>}
            {error && <div className="login-error" role="alert">{error}</div>}
            <button className="login-submit" type="submit">{authMode === "login" ? "Đăng nhập" : "Tạo tài khoản"} <Icon name="arrow" size={18}/></button>
          </form>

          {authMode === "login" && <div className="demo-note">
            <Icon name="shield" size={17}/>
            <p><b>Chế độ trải nghiệm</b><span>Mật khẩu cho cả hai tài khoản: <strong>123456</strong></span></p>
          </div>}
          <div className="auth-switch">{authMode === "login" ? "Chưa có tài khoản?" : "Đã có tài khoản?"}<button type="button" onClick={() => switchMode(authMode === "login" ? "register" : "login")}>{authMode === "login" ? "Đăng ký ngay" : "Đăng nhập"}</button></div>
        </div>
        <p className="login-footer">© 2026 FilmLab · Nền tảng dành cho cộng đồng nhiếp ảnh film Việt Nam</p>
      </section>
    </main>
  );
}

const adminNav = [
  { label: "Tổng quan", icon: "grid" },
  { label: "Không gian", icon: "building" },
  { label: "Thiết bị", icon: "tool" },
  { label: "Lịch đặt chỗ", icon: "calendar" },
  { label: "Báo cáo", icon: "report" },
];

type ManagedSpace = (typeof spaces)[number] & { status: string };
type EquipmentItem = { name: string; location: string; status: string };
type BookingItem = { id: string; customer: string; space: string; time: string; status: string };
type AdminModal = { kind: "space" | "equipment" | "booking"; mode: "create" | "edit" | "view"; id?: string };

const initialBookings: BookingItem[] = [
  { id: "FL-2408", customer: "Minh Anh", space: "Saigon Darkroom 36", time: "09:00 – 11:00", status: "Đã xác nhận" },
  { id: "FL-2409", customer: "Hoàng Nam", space: "The Grain Studio", time: "13:00 – 15:00", status: "Chờ duyệt" },
  { id: "FL-2410", customer: "Thanh Hà", space: "Noir Film Lab", time: "18:00 – 20:00", status: "Đã xác nhận" },
];

const initialEquipment: EquipmentItem[] = [
  { name: "Máy scan Noritsu HS-1800", location: "Saigon Darkroom 36", status: "Sẵn sàng" },
  { name: "Máy phóng Durst M670", location: "Saigon Darkroom 36", status: "Đang sử dụng" },
  { name: "Đèn Godox AD600", location: "The Grain Studio", status: "Sẵn sàng" },
  { name: "Máy ảnh Mamiya RZ67", location: "Noir Film Lab", status: "Bảo trì" },
];

function loadAdminData<T>(key: string, fallback: T): T {
  try {
    const saved = localStorage.getItem(key);
    return saved ? JSON.parse(saved) : fallback;
  } catch {
    return fallback;
  }
}

function AdminDashboard({ user, onLogout }: { user: AuthUser; onLogout: () => void }) {
  const [section, setSection] = useState("Tổng quan");
  const [notice, setNotice] = useState("");
  const [searchOpen, setSearchOpen] = useState(false);
  const [search, setSearch] = useState("");
  const [modal, setModal] = useState<AdminModal | null>(null);
  const [managedSpaces, setManagedSpaces] = useState<ManagedSpace[]>(() => loadAdminData("filmlab-admin-spaces", spaces.map(space => ({ ...space, status: "Đang mở" }))));
  const [equipment, setEquipment] = useState<EquipmentItem[]>(() => loadAdminData("filmlab-admin-equipment", initialEquipment));
  const [adminBookings, setAdminBookings] = useState<BookingItem[]>(() => loadAdminData("filmlab-admin-bookings", initialBookings));

  useEffect(() => localStorage.setItem("filmlab-admin-spaces", JSON.stringify(managedSpaces)), [managedSpaces]);
  useEffect(() => localStorage.setItem("filmlab-admin-equipment", JSON.stringify(equipment)), [equipment]);
  useEffect(() => localStorage.setItem("filmlab-admin-bookings", JSON.stringify(adminBookings)), [adminBookings]);

  const notify = (message: string) => {
    setNotice(message);
    window.setTimeout(() => setNotice(""), 2200);
  };

  const normalizedSearch = search.trim().toLowerCase();
  const filteredSpaces = managedSpaces.filter(space => `${space.name} ${space.place} ${space.type}`.toLowerCase().includes(normalizedSearch));
  const filteredEquipment = equipment.filter(item => `${item.name} ${item.location} ${item.status}`.toLowerCase().includes(normalizedSearch));
  const filteredBookings = adminBookings.filter(item => `${item.id} ${item.customer} ${item.space} ${item.status}`.toLowerCase().includes(normalizedSearch));

  const openCreateModal = () => {
    if (section === "Thiết bị") setModal({ kind: "equipment", mode: "create" });
    else if (section === "Lịch đặt chỗ" || section === "Tổng quan") setModal({ kind: "booking", mode: "create" });
    else if (section === "Không gian") setModal({ kind: "space", mode: "create" });
    else exportReport("Tổng hợp vận hành");
  };

  const exportReport = (name: string) => {
    const content = [
      `FILMLAB - ${name.toUpperCase()}`,
      "Thời gian xuất: 08/04/2026",
      "",
      `Tổng doanh thu: 128.400.000đ`,
      `Lượt đặt chỗ: ${adminBookings.length}`,
      `Không gian hoạt động: ${managedSpaces.filter(space => space.status === "Đang mở").length}`,
      `Thiết bị sẵn sàng: ${equipment.filter(item => item.status === "Sẵn sàng").length}/${equipment.length}`,
    ].join("\n");
    const url = URL.createObjectURL(new Blob([content], { type: "text/plain;charset=utf-8" }));
    const link = document.createElement("a");
    link.href = url;
    link.download = `filmlab-${name.toLowerCase().replaceAll(" ", "-")}.txt`;
    link.click();
    URL.revokeObjectURL(url);
    notify(`Đã xuất ${name.toLowerCase()}`);
  };

  const removeItem = (kind: AdminModal["kind"], id: string) => {
    if (!window.confirm("Bạn có chắc muốn xóa mục này?")) return;
    if (kind === "space") setManagedSpaces(current => current.filter(item => item.name !== id));
    if (kind === "equipment") setEquipment(current => current.filter(item => item.name !== id));
    if (kind === "booking") setAdminBookings(current => current.filter(item => item.id !== id));
    setModal(null);
    notify("Đã xóa thành công");
  };

  const saveAdminItem = (event: FormEvent<HTMLFormElement>) => {
    event.preventDefault();
    if (!modal) return;
    const data = new FormData(event.currentTarget);
    if (modal.kind === "space") {
      const item: ManagedSpace = {
        name: String(data.get("name")),
        place: String(data.get("place")),
        type: String(data.get("type")),
        price: Number(data.get("price")),
        status: String(data.get("status")),
        rating: modal.mode === "edit" ? managedSpaces.find(space => space.name === modal.id)?.rating ?? 5 : 5,
        image: modal.mode === "edit" ? managedSpaces.find(space => space.name === modal.id)?.image ?? photos[0] : photos[managedSpaces.length % photos.length],
        badge: modal.mode === "edit" ? managedSpaces.find(space => space.name === modal.id)?.badge ?? "Mới cập nhật" : "Không gian mới",
      };
      setManagedSpaces(current => modal.mode === "create" ? [...current, item] : current.map(space => space.name === modal.id ? item : space));
    }
    if (modal.kind === "equipment") {
      const item = { name: String(data.get("name")), location: String(data.get("location")), status: String(data.get("status")) };
      setEquipment(current => modal.mode === "create" ? [...current, item] : current.map(equipmentItem => equipmentItem.name === modal.id ? item : equipmentItem));
    }
    if (modal.kind === "booking") {
      const item = {
        id: modal.mode === "create" ? `FL-${2411 + adminBookings.length}` : String(modal.id),
        customer: String(data.get("customer")),
        space: String(data.get("space")),
        time: String(data.get("time")),
        status: String(data.get("status")),
      };
      setAdminBookings(current => modal.mode === "create" ? [item, ...current] : current.map(booking => booking.id === modal.id ? item : booking));
    }
    setModal(null);
    notify(modal.mode === "create" ? "Đã tạo mới thành công" : "Đã lưu thay đổi");
  };

  const editingSpace = modal?.kind === "space" ? managedSpaces.find(item => item.name === modal.id) : undefined;
  const editingEquipment = modal?.kind === "equipment" ? equipment.find(item => item.name === modal.id) : undefined;
  const editingBooking = modal?.kind === "booking" ? adminBookings.find(item => item.id === modal.id) : undefined;

  return (
    <div className="admin-shell">
      <aside className="admin-sidebar">
        <div className="admin-brand"><span className="brand-mark"><Icon name="camera" size={18}/></span><span>FILM<span>LAB</span></span></div>
        <span className="admin-label">TRUNG TÂM QUẢN TRỊ</span>
        <nav>
          {adminNav.map(item => (
            <button key={item.label} className={section === item.label ? "active" : ""} onClick={() => setSection(item.label)}>
              <Icon name={item.icon} size={18}/>{item.label}
            </button>
          ))}
        </nav>
        <div className="admin-user">
          <span>QT</span>
          <div><b>{user.name}</b><small>Quản trị hệ thống</small></div>
          <button onClick={onLogout} aria-label="Đăng xuất"><Icon name="logout" size={17}/></button>
        </div>
      </aside>

      <main className="admin-main">
        <header className="admin-topbar">
          <div><span>FILMLAB ADMIN</span><h1>{section}</h1></div>
          <div className="admin-top-actions">
            {searchOpen && <input className="admin-search-input" autoFocus value={search} onChange={event => setSearch(event.target.value)} placeholder="Tìm theo tên, mã, trạng thái..."/>}
            <button className="admin-search" onClick={() => { setSearchOpen(value => !value); if (searchOpen) setSearch(""); }}><Icon name={searchOpen ? "close" : "search"} size={17}/> {searchOpen ? "Đóng" : "Tìm kiếm"}</button>
            <button className="admin-primary" onClick={openCreateModal}><Icon name={section === "Báo cáo" ? "report" : "plus"} size={17}/> {section === "Báo cáo" ? "Xuất tổng hợp" : "Tạo mới"}</button>
          </div>
        </header>

        {section === "Tổng quan" && (
          <>
            <section className="metric-grid">
              {[
                ["Doanh thu tháng", "128,4 triệu", "+18,2%", "chart"],
                ["Lượt đặt chỗ", "286", "+24 lượt", "calendar"],
                ["Tỷ lệ lấp đầy", "78%", "+6,4%", "building"],
                ["Thiết bị hoạt động", "42 / 46", "91,3%", "tool"],
              ].map(metric => (
                <article key={metric[0]}><div><span>{metric[0]}</span><Icon name={metric[3]} size={19}/></div><strong>{metric[1]}</strong><small>{metric[2]} so với tháng trước</small></article>
              ))}
            </section>
            <section className="admin-grid">
              <article className="admin-card revenue-card">
                <div className="admin-card-head"><div><span>HIỆU QUẢ KINH DOANH</span><h2>Doanh thu 6 tháng</h2></div><b>Đơn vị: triệu đồng</b></div>
                <div className="chart-bars">
                  {[52, 67, 58, 79, 72, 92].map((height, index) => <div key={index}><span style={{height:`${height}%`}}></span><small>{["T.11","T.12","T.01","T.02","T.03","T.04"][index]}</small></div>)}
                </div>
              </article>
              <article className="admin-card occupancy-card">
                <div className="admin-card-head"><div><span>CÔNG SUẤT HÔM NAY</span><h2>Theo không gian</h2></div></div>
                {[["Saigon Darkroom 36",86],["The Grain Studio",72],["Noir Film Lab",64]].map(item => <div className="progress-row" key={item[0]}><div><span>{item[0]}</span><b>{item[1]}%</b></div><i><span style={{width:`${item[1]}%`}}></span></i></div>)}
              </article>
            </section>
            <AdminBookings items={filteredBookings.slice(0, 3)} onView={id => setModal({ kind: "booking", mode: "view", id })} onStatus={(id, status) => { setAdminBookings(current => current.map(item => item.id === id ? {...item, status} : item)); notify("Đã cập nhật lịch đặt chỗ"); }}/>
          </>
        )}

        {section === "Không gian" && (
          <section className="admin-card admin-table-card">
            <div className="admin-card-head"><div><span>DANH MỤC VẬN HÀNH</span><h2>Không gian sáng tạo</h2></div><b>3 không gian đang hoạt động</b></div>
            <div className="admin-list">
              {filteredSpaces.map(space => <div className="space-admin-row" key={space.name}><img src={space.image} alt=""/><div><b>{space.name}</b><span>{space.type} · {space.place}</span></div><strong>{space.price}.000đ/giờ</strong><span className={`status ${space.status === "Đang mở" ? "success-status" : "warning-status"}`}>{space.status}</span><button onClick={() => setModal({ kind: "space", mode: "edit", id: space.name })}>Chỉnh sửa</button></div>)}
              {!filteredSpaces.length && <div className="admin-empty">Không tìm thấy không gian phù hợp.</div>}
            </div>
          </section>
        )}

        {section === "Thiết bị" && (
          <section className="admin-card admin-table-card">
            <div className="admin-card-head"><div><span>QUẢN LÝ TÀI NGUYÊN</span><h2>Thiết bị</h2></div><b>46 thiết bị</b></div>
            <div className="equipment-grid">
              {filteredEquipment.map(item => <article key={item.name}><span className="equipment-icon"><Icon name="camera"/></span><div><b>{item.name}</b><small>{item.location}</small></div><span className={`status ${item.status === "Bảo trì" ? "warning-status" : "success-status"}`}>{item.status}</span><button onClick={() => setModal({ kind: "equipment", mode: "edit", id: item.name })}>Chi tiết</button></article>)}
            </div>
          </section>
        )}

        {section === "Lịch đặt chỗ" && <AdminBookings items={filteredBookings} onView={id => setModal({ kind: "booking", mode: "view", id })} onStatus={(id, status) => { setAdminBookings(current => current.map(item => item.id === id ? {...item, status} : item)); notify("Đã cập nhật lịch đặt chỗ"); }} expanded/>}

        {section === "Báo cáo" && (
          <section className="reports-grid">
            {[["Báo cáo doanh thu","Tổng hợp doanh thu, giao dịch và mức tăng trưởng.","Tháng 04/2026"],["Hiệu suất không gian","Công suất sử dụng và khung giờ được đặt nhiều nhất.","30 ngày gần nhất"],["Tình trạng thiết bị","Lịch sử sử dụng, bảo trì và tỷ lệ sẵn sàng.","Cập nhật hôm nay"],["Hành vi khách hàng","Khách hàng quay lại, nhu cầu và phân khúc nổi bật.","Quý II/2026"]].map(report => <article className="admin-card report-card" key={report[0]}><Icon name="report" size={24}/><div><h2>{report[0]}</h2><p>{report[1]}</p><span>{report[2]}</span></div><button onClick={() => exportReport(report[0])}>Xuất báo cáo <Icon name="arrow" size={15}/></button></article>)}
          </section>
        )}
        {notice && <div className="admin-toast">{notice}</div>}
      </main>
      {modal && (
        <div className="modal-backdrop admin-modal-backdrop" onMouseDown={() => setModal(null)}>
          <div className="modal admin-editor" onMouseDown={event => event.stopPropagation()}>
            <button className="modal-close" onClick={() => setModal(null)}><Icon name="close"/></button>
            <span className="kicker">{modal.mode === "create" ? "TẠO MỚI" : modal.mode === "view" ? "CHI TIẾT ĐẶT CHỖ" : "CHỈNH SỬA"}</span>
            <h2>{modal.kind === "space" ? "Không gian sáng tạo" : modal.kind === "equipment" ? "Thiết bị" : "Lịch đặt chỗ"}</h2>
            {modal.kind === "booking" && modal.mode === "view" && editingBooking ? (
              <div className="booking-detail">
                <div className="booking-detail-code"><div><span>MÃ ĐẶT CHỖ</span><b>{editingBooking.id}</b></div><span className={`status ${editingBooking.status === "Chờ duyệt" || editingBooking.status === "Đã hủy" ? "warning-status" : "success-status"}`}>{editingBooking.status === "Chờ duyệt" ? "Chờ phê duyệt" : editingBooking.status}</span></div>
                <div className="booking-detail-grid">
                  <div><span>Khách hàng</span><b>{editingBooking.customer}</b><small>khachhang@filmlab.vn · 090 123 4567</small></div>
                  <div><span>Ngày sử dụng</span><b>08 tháng 04, 2026</b><small>Thứ tư</small></div>
                  <div><span>Không gian</span><b>{editingBooking.space}</b><small>{managedSpaces.find(space => space.name === editingBooking.space)?.place}</small></div>
                  <div><span>Khung giờ</span><b>{editingBooking.time}</b><small>Thời lượng 2 giờ</small></div>
                </div>
                <div className="booking-detail-resource"><Icon name="camera" size={19}/><div><span>Thiết bị đi kèm</span><b>Máy scan film Noritsu HS-1800</b></div><span className="status success-status">Sẵn sàng</span></div>
                <div className="booking-detail-total"><span>Tổng thanh toán</span><b>{(managedSpaces.find(space => space.name === editingBooking.space)?.price ?? 200) * 2}.000đ</b></div>
                <div className="booking-detail-actions">
                  <button className="pending-action" disabled={editingBooking.status === "Chờ duyệt"} onClick={() => { setAdminBookings(current => current.map(item => item.id === editingBooking.id ? {...item, status:"Chờ duyệt"} : item)); notify("Đã chuyển về chờ phê duyệt"); }}>Chờ phê duyệt</button>
                  <button className="confirm-action" disabled={editingBooking.status === "Đã xác nhận"} onClick={() => { setAdminBookings(current => current.map(item => item.id === editingBooking.id ? {...item, status:"Đã xác nhận"} : item)); notify("Đã xác nhận lịch đặt chỗ"); }}>Xác nhận lịch</button>
                  <button className="edit-detail-action" onClick={() => setModal({ kind:"booking", mode:"edit", id:editingBooking.id })}><Icon name="edit" size={15}/> Chỉnh sửa chi tiết</button>
                </div>
              </div>
            ) : <form onSubmit={saveAdminItem}>
              {modal.kind === "space" && <>
                <label>Tên không gian<input name="name" defaultValue={editingSpace?.name} required/></label>
                <div className="editor-grid"><label>Loại hình<select name="type" defaultValue={editingSpace?.type ?? "Phòng tối"}><option>Phòng tối</option><option>Studio</option></select></label><label>Giá mỗi giờ<input name="price" type="number" min="0" defaultValue={editingSpace?.price ?? 200} required/></label></div>
                <label>Địa chỉ<input name="place" defaultValue={editingSpace?.place} required/></label>
                <label>Trạng thái<select name="status" defaultValue={editingSpace?.status ?? "Đang mở"}><option>Đang mở</option><option>Tạm đóng</option><option>Bảo trì</option></select></label>
              </>}
              {modal.kind === "equipment" && <>
                <label>Tên thiết bị<input name="name" defaultValue={editingEquipment?.name} required/></label>
                <label>Không gian quản lý<select name="location" defaultValue={editingEquipment?.location ?? managedSpaces[0]?.name}>{managedSpaces.map(space => <option key={space.name}>{space.name}</option>)}</select></label>
                <label>Trạng thái<select name="status" defaultValue={editingEquipment?.status ?? "Sẵn sàng"}><option>Sẵn sàng</option><option>Đang sử dụng</option><option>Bảo trì</option></select></label>
              </>}
              {modal.kind === "booking" && <>
                <label>Tên khách hàng<input name="customer" defaultValue={editingBooking?.customer} required/></label>
                <label>Không gian<select name="space" defaultValue={editingBooking?.space ?? managedSpaces[0]?.name}>{managedSpaces.map(space => <option key={space.name}>{space.name}</option>)}</select></label>
                <div className="editor-grid"><label>Khung giờ<select name="time" defaultValue={editingBooking?.time ?? "09:00 – 11:00"}><option>09:00 – 11:00</option><option>13:00 – 15:00</option><option>18:00 – 20:00</option></select></label><label>Trạng thái<select name="status" defaultValue={editingBooking?.status ?? "Chờ duyệt"}><option>Chờ duyệt</option><option>Đã xác nhận</option><option>Đã hoàn tất</option><option>Đã hủy</option></select></label></div>
              </>}
              <div className="editor-actions">
                {modal.mode === "edit" && modal.id && <button type="button" className="delete-action" onClick={() => removeItem(modal.kind, modal.id!)}>Xóa</button>}
                <button type="button" className="cancel-action" onClick={() => setModal(null)}>Hủy</button>
                <button type="submit" className="save-action">{modal.mode === "create" ? "Tạo mới" : "Lưu thay đổi"}</button>
              </div>
            </form>}
          </div>
        </div>
      )}
    </div>
  );
}

function AdminBookings({ items, onView, onStatus, expanded = false }: { items: BookingItem[]; onView: (id: string) => void; onStatus: (id: string, status: string) => void; expanded?: boolean }) {
  return (
    <section className="admin-card admin-table-card bookings-card">
      <div className="admin-card-head"><div><span>LỊCH VẬN HÀNH</span><h2>{expanded ? "Quản lý lịch đặt chỗ" : "Đặt chỗ hôm nay"}</h2></div><b>Thứ tư, 08/04/2026</b></div>
      <div className="booking-table">
        <div className="booking-table-head"><span>Mã</span><span>Khách hàng</span><span>Không gian</span><span>Khung giờ</span><span>Trạng thái</span><span></span></div>
        {items.map(item => <div className="booking-row" key={item.id}><b>{item.id}</b><span>{item.customer}</span><span>{item.space}</span><span>{item.time}</span><select className={`booking-status-select ${item.status === "Chờ duyệt" || item.status === "Đã hủy" ? "pending" : "confirmed"}`} value={item.status} onChange={event => onStatus(item.id, event.target.value)} aria-label={`Trạng thái ${item.id}`}><option value="Chờ duyệt">Chờ phê duyệt</option><option>Đã xác nhận</option><option>Đã hoàn tất</option><option>Đã hủy</option></select><button onClick={() => onView(item.id)}>Xem chi tiết</button></div>)}
        {!items.length && <div className="admin-empty">Không tìm thấy lịch đặt chỗ phù hợp.</div>}
      </div>
    </section>
  );
}

type ChatMessage = { from: "bot" | "user"; text: string };

function Chatbot({ open, onOpenChange }: { open: boolean; onOpenChange: (open: boolean) => void }) {
  const [input, setInput] = useState("");
  const [messages, setMessages] = useState<ChatMessage[]>([
    { from: "bot", text: "Chào An! Mình có thể gợi ý phòng tối, studio hoặc thiết bị phù hợp với concept của bạn." },
  ]);

  const sendMessage = (event: FormEvent<HTMLFormElement>) => {
    event.preventDefault();
    const question = input.trim();
    if (!question) return;
    const normalized = question.toLowerCase();
    let answer = "Mình gợi ý Saigon Darkroom 36 — không gian được đánh giá 4.9/5, phù hợp cả người mới và người đã có kinh nghiệm.";
    if (normalized.includes("studio") || normalized.includes("chân dung")) answer = "The Grain Studio phù hợp nhất cho chụp chân dung: ánh sáng linh hoạt, có phông nền và còn lịch 13:00–15:00 ngày 08/04.";
    if (normalized.includes("hà nội")) answer = "Tại Hà Nội, Noir Film Lab ở Ba Đình là lựa chọn phù hợp. Giá 220.000đ/giờ và có dịch vụ scan film.";
    if (normalized.includes("rẻ") || normalized.includes("giá")) answer = "Saigon Darkroom 36 có mức giá tốt nhất: 180.000đ/giờ. Đặt 2 giờ dự kiến 360.000đ.";
    setMessages(current => [...current, { from: "user", text: question }, { from: "bot", text: answer }]);
    setInput("");
  };

  return (
    <>
      {open && <aside className="chat-panel" aria-label="Trợ lý FilmLab AI">
        <div className="chat-head"><div className="chat-avatar"><Icon name="spark" size={18}/></div><div><b>FilmLab AI</b><span><i></i> Đang trực tuyến</span></div><button onClick={() => onOpenChange(false)} aria-label="Đóng"><Icon name="close" size={19}/></button></div>
        <div className="chat-messages">
          {messages.map((message, index) => <div key={index} className={`chat-message ${message.from}`}>{message.text}</div>)}
        </div>
        <div className="chat-chips">
          {["Phòng tối giá tốt", "Studio chân dung", "Không gian Hà Nội"].map(chip => <button key={chip} onClick={() => setInput(chip)}>{chip}</button>)}
        </div>
        <form className="chat-input" onSubmit={sendMessage}><input value={input} onChange={event => setInput(event.target.value)} placeholder="Mô tả concept của bạn..."/><button aria-label="Gửi tin nhắn"><Icon name="send" size={17}/></button></form>
        <small>Trợ lý đang ở chế độ trải nghiệm với dữ liệu mẫu.</small>
      </aside>}
      <button className={`chat-fab ${open ? "is-open" : ""}`} onClick={() => onOpenChange(!open)} aria-label={open ? "Đóng trợ lý" : "Mở trợ lý FilmLab AI"}>{open ? <Icon name="close"/> : <><Icon name="message"/><span>Hỏi FilmLab AI</span></>}</button>
    </>
  );
}

const restorationDemo = "https://images.unsplash.com/photo-1587483169491-8db3935b2988?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&q=82&w=1200";

function RestorationStudio() {
  const [source, setSource] = useState(restorationDemo);
  const [fileName, setFileName] = useState("anh-mau-phuc-che.jpg");
  const [mode, setMode] = useState<"restore" | "beauty" | "colorize">("restore");
  const [intensity, setIntensity] = useState(72);
  const [comparison, setComparison] = useState(54);
  const [processed, setProcessed] = useState(true);
  const [processing, setProcessing] = useState(false);
  const [brightness, setBrightness] = useState(0);
  const [contrast, setContrast] = useState(0);
  const [saturation, setSaturation] = useState(0);
  const [warmth, setWarmth] = useState(0);
  const [rotation, setRotation] = useState(0);
  const [flipped, setFlipped] = useState(false);
  const [features, setFeatures] = useState({ denoise: true, scratches: true, face: false });
  const [format, setFormat] = useState<"jpeg" | "png">("jpeg");
  const [quality, setQuality] = useState(92);

  const modeValues = mode === "beauty"
    ? { brightness: 100 + intensity * .12, contrast: 100 + intensity * .08, saturation: 100 + intensity * .18, sepia: 0, grayscale: 0 }
    : mode === "colorize"
      ? { brightness: 103, contrast: 108, saturation: 100 + intensity * 1.25, sepia: 25 + intensity * .55, grayscale: 0 }
      : { brightness: 100 + intensity * .08, contrast: 105 + intensity * .2, saturation: 90 + intensity * .35, sepia: 0, grayscale: Math.max(0, 35 - intensity * .35) };
  const imageFilter = `brightness(${modeValues.brightness + brightness + (features.face ? 3 : 0)}%) contrast(${modeValues.contrast + contrast}%) saturate(${modeValues.saturation + saturation}%) sepia(${Math.max(0, modeValues.sepia + warmth * .35)}%) grayscale(${modeValues.grayscale}%) hue-rotate(${warmth * -.18}deg)${features.denoise ? " blur(.15px)" : ""}`;
  const imageTransform = `rotate(${rotation}deg) scaleX(${flipped ? -1 : 1})`;

  const handleUpload = (event: React.ChangeEvent<HTMLInputElement>) => {
    const file = event.target.files?.[0];
    if (!file) return;
    if (!file.type.startsWith("image/")) {
      alert("Vui lòng chọn tệp ảnh JPG, PNG hoặc WEBP.");
      return;
    }
    if (file.size > 10 * 1024 * 1024) {
      alert("Dung lượng ảnh tối đa là 10MB.");
      return;
    }
    const reader = new FileReader();
    reader.onload = () => {
      setSource(String(reader.result));
      setFileName(file.name);
      setProcessed(false);
    };
    reader.readAsDataURL(file);
  };

  const processImage = () => {
    setProcessing(true);
    window.setTimeout(() => {
      setProcessed(true);
      setProcessing(false);
    }, 850);
  };

  const downloadImage = () => {
    const image = new Image();
    image.crossOrigin = "anonymous";
    image.onload = () => {
      const canvas = document.createElement("canvas");
      const maxWidth = 1800;
      const scale = Math.min(1, maxWidth / image.naturalWidth);
      const width = image.naturalWidth * scale;
      const height = image.naturalHeight * scale;
      const rotated = Math.abs(rotation % 180) === 90;
      canvas.width = rotated ? height : width;
      canvas.height = rotated ? width : height;
      const context = canvas.getContext("2d");
      if (!context) return;
      context.filter = imageFilter;
      context.translate(canvas.width / 2, canvas.height / 2);
      context.rotate(rotation * Math.PI / 180);
      context.scale(flipped ? -1 : 1, 1);
      context.drawImage(image, -width / 2, -height / 2, width, height);
      try {
        const link = document.createElement("a");
        link.href = canvas.toDataURL(`image/${format}`, quality / 100);
        link.download = `filmlab-${fileName.replace(/\.[^.]+$/, "")}.${format === "jpeg" ? "jpg" : "png"}`;
        link.click();
      } catch {
        alert("Hãy tải ảnh của bạn lên để tải xuống bản đã xử lý.");
      }
    };
    image.onerror = () => alert("Không thể xuất ảnh mẫu. Hãy thử tải ảnh của bạn lên.");
    image.src = source;
  };

  const selectMode = (nextMode: typeof mode) => {
    setMode(nextMode);
    setProcessed(false);
  };

  const updateAdjustment = (setter: (value: number) => void, value: number) => {
    setter(value);
    setProcessed(false);
  };

  const applyPreset = (preset: "natural" | "portrait" | "vintage" | "bw") => {
    const values = {
      natural: { brightness: 2, contrast: 6, saturation: 8, warmth: 2 },
      portrait: { brightness: 8, contrast: -2, saturation: 5, warmth: 10 },
      vintage: { brightness: -3, contrast: 12, saturation: -8, warmth: 22 },
      bw: { brightness: 3, contrast: 18, saturation: -100, warmth: 0 },
    }[preset];
    setBrightness(values.brightness);
    setContrast(values.contrast);
    setSaturation(values.saturation);
    setWarmth(values.warmth);
    setProcessed(false);
  };

  const resetAdjustments = () => {
    setBrightness(0);
    setContrast(0);
    setSaturation(0);
    setWarmth(0);
    setIntensity(72);
    setRotation(0);
    setFlipped(false);
    setFeatures({ denoise: true, scratches: true, face: false });
    setProcessed(false);
  };

  return (
    <section className="restoration" id="restoration">
      <div className="restoration-head">
        <div><span className="kicker">PHÒNG ẢNH KỸ THUẬT SỐ</span><h2>Phục chế & làm đẹp ảnh film</h2><p>Khôi phục chi tiết, cân bằng màu và làm đẹp ảnh cũ chỉ trong vài bước.</p></div>
        <div className="restore-badge"><Icon name="spark" size={16}/><span><b>FilmLab Enhance</b><small>Chế độ trải nghiệm</small></span></div>
      </div>
      <div className="restoration-workspace">
        <div className="restore-toolbar">
          <button onClick={() => { setRotation(value => value - 90); setProcessed(false); }}><Icon name="rotate" size={15}/> Xoay trái</button>
          <button onClick={() => { setRotation(value => value + 90); setProcessed(false); }}><Icon name="rotate" size={15}/> Xoay phải</button>
          <button onClick={() => { setFlipped(value => !value); setProcessed(false); }} className={flipped ? "active" : ""}><Icon name="flip" size={15}/> Lật ảnh</button>
          <button onClick={resetAdjustments}><Icon name="reset" size={15}/> Đặt lại</button>
        </div>
        <div className="restore-preview">
          <img src={source} alt="Ảnh gốc cần phục chế" style={{transform:imageTransform}}/>
          {processed && <div className="enhanced-layer" style={{clipPath:`inset(0 ${100 - comparison}% 0 0)`}}><img src={source} alt="Ảnh sau khi phục chế" style={{filter:imageFilter, transform:imageTransform}}/></div>}
          {processed && <div className="compare-line" style={{left:`${comparison}%`}}><span>↔</span></div>}
          <span className="before-label">ẢNH GỐC</span><span className="after-label">SAU XỬ LÝ</span>
          {processing && <div className="processing-overlay"><Icon name="spark" size={27}/><b>Đang phục chế ảnh...</b><span>Phân tích màu sắc và chi tiết</span></div>}
        </div>
        {processed && <label className="compare-control">Kéo để so sánh trước và sau<input type="range" min="5" max="95" value={comparison} onChange={event => setComparison(Number(event.target.value))}/></label>}
        <p className="restore-credit">Ảnh mẫu bởi Brett Jordan · Unsplash</p>
      </div>
      <aside className="restore-controls">
        <div className="upload-box">
          <input id="restore-upload" type="file" accept="image/jpeg,image/png,image/webp" onChange={handleUpload}/>
          <label htmlFor="restore-upload"><Icon name="upload" size={20}/><span><b>Tải ảnh của bạn lên</b><small>JPG, PNG hoặc WEBP · Tối đa 10MB</small></span></label>
        </div>
        <div className="control-section">
          <span>CHỌN CHẾ ĐỘ XỬ LÝ</span>
          <div className="restore-modes">
            <button className={mode === "restore" ? "active" : ""} onClick={() => selectMode("restore")}><Icon name="wand" size={18}/><span><b>Phục chế</b><small>Khôi phục màu & chi tiết</small></span></button>
            <button className={mode === "beauty" ? "active" : ""} onClick={() => selectMode("beauty")}><Icon name="spark" size={18}/><span><b>Làm đẹp</b><small>Sáng da & cân bằng ảnh</small></span></button>
            <button className={mode === "colorize" ? "active" : ""} onClick={() => selectMode("colorize")}><Icon name="image" size={18}/><span><b>Tô màu</b><small>Thêm màu cho ảnh cũ</small></span></button>
          </div>
        </div>
        <div className="intensity-control"><div><span>Cường độ xử lý</span><b>{intensity}%</b></div><input type="range" min="10" max="100" value={intensity} onChange={event => { setIntensity(Number(event.target.value)); setProcessed(false); }}/></div>
        <div className="advanced-controls">
          <span>PRESET MÀU</span>
          <div className="preset-grid"><button onClick={() => applyPreset("natural")}>Tự nhiên</button><button onClick={() => applyPreset("portrait")}>Chân dung</button><button onClick={() => applyPreset("vintage")}>Vintage</button><button onClick={() => applyPreset("bw")}>Đen trắng</button></div>
          {[["Độ sáng",brightness,setBrightness],["Tương phản",contrast,setContrast],["Bão hòa",saturation,setSaturation],["Độ ấm",warmth,setWarmth]].map(([label,value,setter]) => <label className="adjustment-row" key={String(label)}><div><span>{String(label)}</span><b>{Number(value) > 0 ? "+" : ""}{String(value)}</b></div><input type="range" min="-40" max="40" value={Number(value)} onChange={event => updateAdjustment(setter as (value:number) => void, Number(event.target.value))}/></label>)}
        </div>
        <div className="restore-features">
          <label><span><b>Khử nhiễu thông minh</b><small>Làm mịn hạt và nhiễu màu</small></span><input type="checkbox" checked={features.denoise} onChange={() => { setFeatures({...features, denoise:!features.denoise}); setProcessed(false); }}/><i></i></label>
          <label><span><b>Xóa vết xước</b><small>Phát hiện vùng ảnh bị hư hỏng</small></span><input type="checkbox" checked={features.scratches} onChange={() => { setFeatures({...features, scratches:!features.scratches}); setProcessed(false); }}/><i></i></label>
          <label><span><b>Làm rõ khuôn mặt</b><small>Tối ưu ánh sáng và sắc da</small></span><input type="checkbox" checked={features.face} onChange={() => { setFeatures({...features, face:!features.face}); setProcessed(false); }}/><i></i></label>
        </div>
        <div className="export-options"><label>Định dạng<select value={format} onChange={event => setFormat(event.target.value as "jpeg" | "png")}><option value="jpeg">JPG</option><option value="png">PNG</option></select></label><label>Chất lượng<select value={quality} onChange={event => setQuality(Number(event.target.value))}><option value="80">Tiêu chuẩn</option><option value="92">Cao</option><option value="100">Tối đa</option></select></label></div>
        <button className="process-button" onClick={processImage} disabled={processing}><Icon name="wand" size={18}/>{processing ? "Đang xử lý..." : "Bắt đầu xử lý ảnh"}</button>
        <button className="download-button" onClick={downloadImage} disabled={!processed}><Icon name="download" size={17}/> Tải ảnh đã xử lý</button>
      </aside>
    </section>
  );
}

type CommunityPost = {
  id: number;
  author: string;
  initials: string;
  time: string;
  category: string;
  content: string;
  image?: string;
  likes: number;
  liked: boolean;
  saved: boolean;
  comments: string[];
};

type CustomerReview = {
  id: number;
  author: string;
  initials: string;
  space: string;
  rating: number;
  comment: string;
  date: string;
  helpful: number;
  voted: boolean;
};

const initialReviews: CustomerReview[] = [
  { id: 1, author: "Mai Phương", initials: "MP", space: "Saigon Darkroom 36", rating: 5, comment: "Phòng tối sạch, đầy đủ dụng cụ và nhân viên hướng dẫn rất tận tâm. Mình lần đầu tự tráng film nhưng trải nghiệm rất dễ chịu.", date: "02/04/2026", helpful: 18, voted: false },
  { id: 2, author: "Quang Huy", initials: "QH", space: "The Grain Studio", rating: 4, comment: "Ánh sáng đẹp, nhiều phông nền và thiết bị hoạt động tốt. Studio hơi đông vào cuối tuần nên mọi người nên đặt lịch sớm.", date: "28/03/2026", helpful: 11, voted: false },
  { id: 3, author: "Thảo Nguyên", initials: "TN", space: "Noir Film Lab", rating: 5, comment: "Không gian ấm cúng, bản scan có màu rất đúng ý. Chắc chắn mình sẽ quay lại cho cuộn film tiếp theo.", date: "21/03/2026", helpful: 24, voted: false },
];

function StarRating({ value, interactive = false, onChange, size = 15 }: { value: number; interactive?: boolean; onChange?: (rating: number) => void; size?: number }) {
  return <div className={`stars ${interactive ? "interactive" : ""}`} aria-label={`${value} trên 5 sao`}>{[1,2,3,4,5].map(star => <button type="button" key={star} disabled={!interactive} className={star <= value ? "filled" : ""} onClick={() => onChange?.(star)} aria-label={`${star} sao`}><Icon name="star" size={size}/></button>)}</div>;
}

function CustomerReviews() {
  const [reviews, setReviews] = useState<CustomerReview[]>(() => loadAdminData("filmlab-reviews", initialReviews));
  const [selectedSpace, setSelectedSpace] = useState(spaces[0].name);
  const [rating, setRating] = useState(5);
  const [comment, setComment] = useState("");
  const [filter, setFilter] = useState("Tất cả");
  const [notice, setNotice] = useState("");

  useEffect(() => localStorage.setItem("filmlab-reviews", JSON.stringify(reviews)), [reviews]);

  const submitReview = (event: FormEvent<HTMLFormElement>) => {
    event.preventDefault();
    if (comment.trim().length < 10) {
      setNotice("Nhận xét cần có ít nhất 10 ký tự.");
      return;
    }
    setReviews(current => [{
      id: Date.now(), author: "An Nguyễn", initials: "AN", space: selectedSpace, rating,
      comment: comment.trim(), date: "08/04/2026", helpful: 0, voted: false,
    }, ...current]);
    setComment("");
    setRating(5);
    setNotice("Cảm ơn bạn! Đánh giá đã được đăng.");
    window.setTimeout(() => setNotice(""), 2200);
  };

  const visibleReviews = filter === "Tất cả" ? reviews : reviews.filter(review => review.rating === Number(filter));
  const historicalRatings: Record<number, number> = { 5: 1134, 4: 99, 3: 12, 2: 0, 1: 0 };
  const verifiedReviewCount = 1245 + reviews.length;
  const historicalScore = Object.entries(historicalRatings).reduce((total, [star, count]) => total + Number(star) * count, 0);
  const average = (historicalScore + reviews.reduce((total, review) => total + review.rating, 0)) / verifiedReviewCount;
  const distribution = [5,4,3,2,1].map(star => {
    const count = historicalRatings[star] + reviews.filter(review => review.rating === star).length;
    return { star, percent: Math.round(count / verifiedReviewCount * 100) };
  });

  return (
    <section className="reviews-section">
      <div className="reviews-head"><div><span className="kicker">TRẢI NGHIỆM THỰC TẾ</span><h2>Đánh giá từ cộng đồng</h2><p>Những chia sẻ chân thực từ khách hàng đã trải nghiệm các không gian trên FilmLab.</p></div><div className="rating-summary"><strong>{average.toFixed(1)}</strong><div><StarRating value={Math.round(average)} size={14}/><span>{verifiedReviewCount.toLocaleString("vi-VN")} đánh giá đã xác thực</span></div></div></div>
      <div className="reviews-layout">
        <aside className="review-overview">
          <h3>Phân bổ đánh giá</h3>
          {distribution.map(item => <div className="rating-bar" key={item.star}><span>{item.star} <Icon name="star" size={10}/></span><i><span style={{width:`${item.percent}%`}}></span></i><b>{item.percent}%</b></div>)}
          <div className="review-filter"><span>Lọc nhận xét</span><div>{["Tất cả","5","4","3"].map(item => <button className={filter === item ? "active" : ""} key={item} onClick={() => setFilter(item)}>{item === "Tất cả" ? item : `${item} sao`}</button>)}</div></div>
        </aside>
        <div className="review-list">
          {visibleReviews.map(review => <article className="review-card" key={review.id}><div className="review-author"><span>{review.initials}</span><div><b>{review.author}</b><small>Khách hàng đã đặt chỗ · {review.date}</small></div><StarRating value={review.rating}/></div><span className="review-space"><Icon name="map" size={12}/> {review.space}</span><p>{review.comment}</p><button className={review.voted ? "voted" : ""} onClick={() => setReviews(current => current.map(item => item.id === review.id ? {...item, voted:!item.voted, helpful:item.helpful + (item.voted ? -1 : 1)} : item))}>Nhận xét hữu ích · {review.helpful}</button></article>)}
          {!visibleReviews.length && <div className="admin-empty">Chưa có đánh giá ở mức sao này.</div>}
        </div>
        <form className="review-form" onSubmit={submitReview}>
          <span className="kicker">CHIA SẺ TRẢI NGHIỆM</span><h3>Viết đánh giá của bạn</h3>
          <label>Không gian đã trải nghiệm<select value={selectedSpace} onChange={event => setSelectedSpace(event.target.value)}>{spaces.map(space => <option key={space.name}>{space.name}</option>)}</select></label>
          <label>Mức độ hài lòng<StarRating value={rating} interactive onChange={setRating} size={20}/><small>{["","Rất không hài lòng","Chưa hài lòng","Bình thường","Hài lòng","Rất hài lòng"][rating]}</small></label>
          <label>Nhận xét<textarea value={comment} onChange={event => { setComment(event.target.value); setNotice(""); }} placeholder="Không gian, thiết bị và chất lượng phục vụ thế nào?"/></label>
          {notice && <p className="review-notice">{notice}</p>}
          <button type="submit">Gửi đánh giá <Icon name="arrow" size={16}/></button>
        </form>
      </div>
    </section>
  );
}

const initialPosts: CommunityPost[] = [
  { id: 1, author: "Linh Trần", initials: "LT", time: "2 giờ trước", category: "Chia sẻ ảnh", content: "Một buổi chiều với Kodak Portra 400 tại Chợ Lớn. Mình rất thích cách cuộn film này giữ lại sắc đỏ và ánh sáng cuối ngày.", image: photos[1], likes: 128, liked: false, saved: false, comments: ["Màu ảnh rất điện ảnh!", "Bạn scan ở lab nào vậy?"] },
  { id: 2, author: "Đức Minh", initials: "ĐM", time: "5 giờ trước", category: "Hỏi đáp", content: "Mọi người có kinh nghiệm đẩy Ilford HP5 lên ISO 1600 không? Mình đang chuẩn bị chụp một đêm nhạc ánh sáng khá yếu.", likes: 42, liked: false, saved: false, comments: ["Có thể push 2 stop, hạt sẽ rõ nhưng rất đẹp."] },
];

function CommunityHub() {
  const [posts, setPosts] = useState<CommunityPost[]>(() => loadAdminData("filmlab-community-posts", initialPosts));
  const [draft, setDraft] = useState("");
  const [category, setCategory] = useState("Chia sẻ ảnh");
  const [activeComment, setActiveComment] = useState<number | null>(null);
  const [comment, setComment] = useState("");
  const [notice, setNotice] = useState("");

  useEffect(() => localStorage.setItem("filmlab-community-posts", JSON.stringify(posts)), [posts]);

  const showNotice = (message: string) => {
    setNotice(message);
    window.setTimeout(() => setNotice(""), 1800);
  };

  const publish = () => {
    if (!draft.trim()) return;
    setPosts(current => [{
      id: Date.now(), author: "An Nguyễn", initials: "AN", time: "Vừa xong", category,
      content: draft.trim(), likes: 0, liked: false, saved: false, comments: [],
    }, ...current]);
    setDraft("");
    showNotice("Bài viết đã được đăng");
  };

  const addComment = (postId: number) => {
    if (!comment.trim()) return;
    setPosts(current => current.map(post => post.id === postId ? { ...post, comments: [...post.comments, comment.trim()] } : post));
    setComment("");
  };

  const sharePost = async () => {
    try {
      await navigator.clipboard.writeText(window.location.href);
      showNotice("Đã sao chép liên kết bài viết");
    } catch {
      showNotice("Đã sẵn sàng để chia sẻ bài viết");
    }
  };

  return (
    <section className="community-section" id="community">
      <div className="community-intro">
        <span className="kicker">CỘNG ĐỒNG FILMLAB</span>
        <h2>Cùng chia sẻ<br/><em>chất film.</em></h2>
        <p>Nơi những người yêu nhiếp ảnh analog trao đổi kinh nghiệm, chia sẻ tác phẩm và tìm cảm hứng mới.</p>
        <div className="community-stats"><div><b>8.4K</b><span>Thành viên</span></div><div><b>2.1K</b><span>Tác phẩm</span></div></div>
      </div>
      <div className="community-feed">
        <article className="post-composer">
          <div className="community-avatar self">AN</div>
          <textarea value={draft} onChange={event => setDraft(event.target.value)} placeholder="Chia sẻ một câu chuyện, kinh nghiệm hoặc tác phẩm của bạn..."/>
          <div className="composer-actions">
            <select value={category} onChange={event => setCategory(event.target.value)}><option>Chia sẻ ảnh</option><option>Hỏi đáp</option><option>Kinh nghiệm</option><option>Tìm cộng sự</option></select>
            <button onClick={publish} disabled={!draft.trim()}>Đăng bài <Icon name="send" size={15}/></button>
          </div>
        </article>
        {posts.map(post => (
          <article className="community-post" key={post.id}>
            <div className="post-author"><div className="community-avatar">{post.initials}</div><div><b>{post.author}</b><span>{post.time} · {post.category}</span></div><button className={post.saved ? "saved" : ""} onClick={() => setPosts(current => current.map(item => item.id === post.id ? {...item, saved: !item.saved} : item))} aria-label="Lưu bài viết"><Icon name="bookmark" size={18}/></button></div>
            <p>{post.content}</p>
            {post.image && <img className="post-image" src={post.image} alt="Tác phẩm film được chia sẻ"/>}
            <div className="post-social-proof"><span>{post.likes} lượt thích</span><span>{post.comments.length} bình luận</span></div>
            <div className="post-actions">
              <button className={post.liked ? "liked" : ""} onClick={() => setPosts(current => current.map(item => item.id === post.id ? {...item, liked: !item.liked, likes: item.likes + (item.liked ? -1 : 1)} : item))}><Icon name="heart" size={17}/> {post.liked ? "Đã thích" : "Thích"}</button>
              <button onClick={() => setActiveComment(activeComment === post.id ? null : post.id)}><Icon name="comment" size={17}/> Bình luận</button>
              <button onClick={sharePost}><Icon name="share" size={17}/> Chia sẻ</button>
            </div>
            {post.comments.length > 0 && <div className="post-comments">{post.comments.map((item, index) => <div key={index}><span>AN</span><p>{item}</p></div>)}</div>}
            {activeComment === post.id && <form className="comment-form" onSubmit={event => { event.preventDefault(); addComment(post.id); }}><span>AN</span><input autoFocus value={comment} onChange={event => setComment(event.target.value)} placeholder="Viết bình luận..."/><button aria-label="Gửi bình luận"><Icon name="send" size={15}/></button></form>}
          </article>
        ))}
      </div>
      {notice && <div className="community-toast">{notice}</div>}
    </section>
  );
}

type ProfileData = { name: string; email: string; phone: string; city: string; bio: string; preferences: string[] };

function ProfileManager({ user, onClose, onSave }: { user: AuthUser; onClose: () => void; onSave: (profile: ProfileData) => void }) {
  const [profile, setProfile] = useState<ProfileData>(() => loadAdminData("filmlab-profile", { name: user.name, email: user.email, phone: "090 123 4567", city: "TP. Hồ Chí Minh", bio: "Yêu thích film màu và những khoảnh khắc đời thường.", preferences: ["Film màu", "Chân dung"] }));
  const [customerBookings] = useState<BookingItem[]>(() => loadAdminData(`filmlab-customer-bookings-${user.email}`, user.email === demoAccounts.customer.email ? initialBookings.slice(0, 2) : []));
  const [savedSpaceNames] = useState<string[]>(() => loadAdminData(`filmlab-saved-spaces-${user.email}`, user.email === demoAccounts.customer.email ? spaces.slice(0, 2).map(space => space.name) : []));
  const savedSpaces = spaces.filter(space => savedSpaceNames.includes(space.name));
  const [tab, setTab] = useState("Hồ sơ");
  const [editing, setEditing] = useState(false);
  const preferenceOptions = ["Film màu", "Film đen trắng", "Chân dung", "Đường phố", "Phòng tối", "Studio"];

  const submitProfile = (event: FormEvent<HTMLFormElement>) => {
    event.preventDefault();
    localStorage.setItem("filmlab-profile", JSON.stringify(profile));
    onSave(profile);
    setEditing(false);
  };

  const togglePreference = (preference: string) => {
    setProfile(current => ({ ...current, preferences: current.preferences.includes(preference) ? current.preferences.filter(item => item !== preference) : [...current.preferences, preference] }));
  };

  return (
    <div className="modal-backdrop profile-backdrop" onMouseDown={onClose}>
      <section className="profile-panel" onMouseDown={event => event.stopPropagation()}>
        <button className="profile-close" onClick={onClose}><Icon name="close"/></button>
        <aside className="profile-sidebar">
          <div className="profile-avatar">AN<button onClick={() => alert("Tính năng tải ảnh đại diện sẽ được kết nối ở phiên bản backend.")}><Icon name="camera" size={14}/></button></div>
          <h2>{profile.name}</h2><p>{profile.email}</p>
          <nav>{["Hồ sơ", ...(customerBookings.length ? ["Lịch đặt"] : []), ...(savedSpaces.length ? ["Đã lưu"] : [])].map(item => <button key={item} className={tab === item ? "active" : ""} onClick={() => setTab(item)}>{item === "Hồ sơ" ? <Icon name="user" size={17}/> : item === "Lịch đặt" ? <Icon name="calendar" size={17}/> : <Icon name="bookmark" size={17}/>} {item}</button>)}</nav>
        </aside>
        <div className="profile-content">
          {tab === "Hồ sơ" && <>
            <div className="profile-content-head"><div><span className="kicker">TÀI KHOẢN CỦA TÔI</span><h2>Thông tin cá nhân</h2></div><button onClick={() => setEditing(!editing)}><Icon name="edit" size={16}/> {editing ? "Hủy chỉnh sửa" : "Chỉnh sửa"}</button></div>
            <form className="profile-form" onSubmit={submitProfile}>
              <div><label>Họ và tên<input disabled={!editing} value={profile.name} onChange={event => setProfile({...profile, name:event.target.value})}/></label><label>Email<input disabled={!editing} type="email" value={profile.email} onChange={event => setProfile({...profile, email:event.target.value})}/></label></div>
              <div><label>Số điện thoại<input disabled={!editing} value={profile.phone} onChange={event => setProfile({...profile, phone:event.target.value})}/></label><label>Thành phố<input disabled={!editing} value={profile.city} onChange={event => setProfile({...profile, city:event.target.value})}/></label></div>
              <label>Giới thiệu<textarea disabled={!editing} value={profile.bio} onChange={event => setProfile({...profile, bio:event.target.value})}/></label>
              <div className="preference-field"><span>Sở thích nhiếp ảnh</span><div>{preferenceOptions.map(item => <button type="button" disabled={!editing} className={profile.preferences.includes(item) ? "active" : ""} key={item} onClick={() => togglePreference(item)}>{item}</button>)}</div></div>
              {editing && <button className="profile-save" type="submit">Lưu thay đổi</button>}
            </form>
          </>}
          {tab === "Lịch đặt" && <><div className="profile-content-head"><div><span className="kicker">HOẠT ĐỘNG GẦN ĐÂY</span><h2>Lịch đặt của tôi</h2></div></div><div className="profile-bookings">{customerBookings.map((item,index) => <article key={item.id}><div className="booking-date"><b>{index === 0 ? "08" : "16"}</b><span>THÁNG 04</span></div><div><h3>{item.space}</h3><p>{item.time} · 2 giờ</p><span className={`status ${item.status === "Chờ duyệt" ? "warning-status" : "success-status"}`}>{item.status === "Chờ duyệt" ? "Chờ phê duyệt" : item.status}</span></div><button onClick={() => alert(`Mã đặt chỗ: ${item.id}`)}>Chi tiết</button></article>)}</div></>}
          {tab === "Đã lưu" && <><div className="profile-content-head"><div><span className="kicker">BỘ SƯU TẬP</span><h2>Không gian đã lưu</h2></div></div><div className="saved-spaces">{savedSpaces.map(space => <article key={space.name}><img src={space.image} alt={space.name}/><div><span>{space.type}</span><h3>{space.name}</h3><p>{space.place}</p></div><button onClick={() => alert(`Đã chọn ${space.name}`)}>Xem phòng</button></article>)}</div></>}
        </div>
      </section>
    </div>
  );
}

export default function App() {
  const [user, setUser] = useState<AuthUser | null>(() => {
    try {
      const savedUser = localStorage.getItem("filmlab-user");
      return savedUser ? JSON.parse(savedUser) : null;
    } catch {
      return null;
    }
  });
  const [active, setActive] = useState("Khám phá");
  const [query, setQuery] = useState("");
  const [type, setType] = useState("Tất cả không gian");
  const [booking, setBooking] = useState<(typeof spaces)[0] | null>(null);
  const [confirmed, setConfirmed] = useState(false);
  const [accountOpen, setAccountOpen] = useState(false);
  const [chatOpen, setChatOpen] = useState(false);
  const [profileOpen, setProfileOpen] = useState(false);
  const [savedSpaceNames, setSavedSpaceNames] = useState<string[]>([]);
  const filtered = useMemo(() => spaces.filter(s => (type === "Tất cả không gian" || s.type === type) && (s.name + s.place).toLowerCase().includes(query.toLowerCase())), [query, type]);

  useEffect(() => {
    if (!user || user.role !== "customer") {
      setSavedSpaceNames([]);
      return;
    }
    setSavedSpaceNames(loadAdminData(`filmlab-saved-spaces-${user.email}`, user.email === demoAccounts.customer.email ? spaces.slice(0, 2).map(space => space.name) : []));
  }, [user]);

  const toggleSavedSpace = (spaceName: string) => {
    if (!user) return;
    setSavedSpaceNames(current => {
      const next = current.includes(spaceName) ? current.filter(name => name !== spaceName) : [...current, spaceName];
      localStorage.setItem(`filmlab-saved-spaces-${user.email}`, JSON.stringify(next));
      return next;
    });
  };

  const handleLogin = (nextUser: AuthUser) => {
    localStorage.setItem("filmlab-user", JSON.stringify(nextUser));
    setUser(nextUser);
  };

  const handleLogout = () => {
    localStorage.removeItem("filmlab-user");
    setUser(null);
    setAccountOpen(false);
  };

  if (!user) {
    return <LoginScreen onLogin={handleLogin}/>;
  }

  if (user.role === "admin") {
    return <AdminDashboard user={user} onLogout={handleLogout}/>;
  }

  return (
    <div className="app-shell">
      <header>
        <button className="brand" onClick={() => setActive("Khám phá")}><span className="brand-mark"><Icon name="camera" size={19}/></span><span>FILM<span>LAB</span></span></button>
        <nav>
          {["Khám phá", "Đặt lịch", "Phục chế ảnh", "Cộng đồng"].map(item => <button key={item} className={active === item ? "active" : ""} onClick={() => { setActive(item); const target = item === "Phục chế ảnh" ? "restoration" : item === "Cộng đồng" ? "community" : item === "Đặt lịch" ? "spaces" : ""; if (target) window.setTimeout(() => document.getElementById(target)?.scrollIntoView({ behavior: "smooth" }), 0); }}>{item}</button>)}
        </nav>
        <div className="header-actions">
          {user.role === "admin" ? <span className="role-badge"><Icon name="shield" size={14}/> Quản trị viên</span> : <button className="host">Trở thành đối tác</button>}
          <div className="account">
            <button className="avatar" onClick={() => setAccountOpen(value => !value)} aria-label="Mở menu tài khoản" aria-expanded={accountOpen}>
              {user.role === "admin" ? "QT" : "AN"}
            </button>
            {accountOpen && (
              <div className="account-menu">
                <div><b>{user.name}</b><span>{user.email}</span></div>
                <button onClick={() => { setProfileOpen(true); setAccountOpen(false); }}><Icon name="user" size={17}/> Hồ sơ cá nhân</button>
                <button onClick={handleLogout}><Icon name="logout" size={17}/> Đăng xuất</button>
              </div>
            )}
          </div>
        </div>
      </header>

      <main>
        <section className="hero">
          <div className="eyebrow"><span></span> KHÔNG GIAN CHO NGƯỜI YÊU FILM</div>
          <h1>Chạm vào <em>chất film.</em><br/>Tạo nên câu chuyện.</h1>
          <p>Khám phá phòng tối, studio và thiết bị chuyên nghiệp — tất cả trong một cộng đồng dành riêng cho nhiếp ảnh analog.</p>
          <div className="search-panel">
            <label><span>Địa điểm hoặc tên studio</span><div><Icon name="search" size={18}/><input value={query} onChange={e => setQuery(e.target.value)} placeholder="Bạn muốn chụp ở đâu?"/></div></label>
            <label><span>Loại không gian</span><select value={type} onChange={e => setType(e.target.value)}><option>Tất cả không gian</option><option>Phòng tối</option><option>Studio</option></select></label>
            <label><span>Ngày sử dụng</span><div><Icon name="calendar" size={18}/><input type="date" defaultValue="2026-04-08"/></div></label>
            <button className="search-btn" onClick={() => document.getElementById("spaces")?.scrollIntoView({behavior:"smooth"})}><Icon name="search" size={19}/> Tìm không gian</button>
          </div>
          <div className="hero-stats"><div><b>120+</b><span>Không gian sáng tạo</span></div><div><b>4.9/5</b><span>Từ cộng đồng</span></div><div><b>24/7</b><span>Hỗ trợ đặt lịch</span></div></div>
        </section>

        <section className="content" id="spaces">
          <div className="section-head">
            <div><span className="kicker">TUYỂN CHỌN CHO BẠN</span><h2>Không gian nổi bật</h2></div>
            <button>Xem tất cả <Icon name="arrow" size={17}/></button>
          </div>
          <div className="cards">
            {filtered.map((space, i) => (
              <article className="space-card" key={space.name}>
                <div className="photo-wrap"><img src={space.image} alt={space.name}/><span className="badge">{space.badge}</span><button className={`heart ${savedSpaceNames.includes(space.name) ? "saved" : ""}`} onClick={() => toggleSavedSpace(space.name)} aria-label={savedSpaceNames.includes(space.name) ? "Bỏ lưu không gian" : "Lưu không gian"}>{savedSpaceNames.includes(space.name) ? "♥" : "♡"}</button></div>
                <div className="card-body">
                  <div className="meta"><span>{space.type}</span><span className="rating"><Icon name="star" size={14}/> {space.rating}</span></div>
                  <h3>{space.name}</h3>
                  <p><Icon name="map" size={15}/> {space.place}</p>
                  <div className="card-footer"><div><strong>{space.price}.000đ</strong><span> / giờ</span></div><button onClick={() => { setBooking(space); setConfirmed(false); }}>Đặt lịch</button></div>
                </div>
              </article>
            ))}
            {!filtered.length && <div className="empty">Không tìm thấy không gian phù hợp. Hãy thử từ khóa khác.</div>}
          </div>
        </section>

        <section className="recommendations">
          <div className="recommend-copy">
            <span className="kicker">GỢI Ý RIÊNG CHO AN</span>
            <h2>Phù hợp với gu của bạn</h2>
            <p>Dựa trên sở thích chụp film màu, vị trí tại TP. Hồ Chí Minh và mức giá bạn thường tìm kiếm.</p>
            <div className="preference-tags"><span>Film màu</span><span>Phòng tối</span><span>Dưới 250.000đ/giờ</span></div>
          </div>
          <div className="recommend-list">
            {spaces.slice(0,2).map((space, index) => <article key={space.name}><img src={space.image} alt={space.name}/><div><span>{index === 0 ? "96% phù hợp" : "89% phù hợp"}</span><h3>{space.name}</h3><p><Icon name="map" size={14}/> {space.place}</p><div><b>{space.price}.000đ / giờ</b><button onClick={() => { setBooking(space); setConfirmed(false); }}>Xem phòng <Icon name="arrow" size={15}/></button></div></div></article>)}
          </div>
        </section>

        <RestorationStudio/>

        <section className="ai-banner">
          <div className="ai-icon"><Icon name="spark" size={25}/></div>
          <div><span>FILMLAB AI</span><h2>Chưa biết bắt đầu từ đâu?</h2><p>Trợ lý AI sẽ gợi ý không gian, thiết bị và gói dịch vụ phù hợp với phong cách của bạn.</p></div>
          <button onClick={() => setChatOpen(true)}>Nhận gợi ý cá nhân <Icon name="arrow" size={18}/></button>
        </section>

        <section className="how">
          <div><span className="kicker">MỌI THỨ THẬT ĐƠN GIẢN</span><h2>Từ ý tưởng đến khoảnh khắc</h2></div>
          <div className="steps">
            <div><b>01</b><Icon name="search"/><h3>Tìm không gian</h3><p>Lọc theo vị trí, phong cách, thiết bị và mức giá.</p></div>
            <div><b>02</b><Icon name="calendar"/><h3>Đặt lịch tức thì</h3><p>Hệ thống tự động kiểm tra tài nguyên và tránh trùng lịch.</p></div>
            <div><b>03</b><Icon name="camera"/><h3>Bắt đầu sáng tạo</h3><p>Check-in bằng QR, sử dụng thiết bị và tận hưởng buổi chụp.</p></div>
          </div>
        </section>
        <CustomerReviews/>
        <CommunityHub/>
      </main>

      <footer><div className="brand"><span className="brand-mark"><Icon name="camera" size={18}/></span>FILMLAB</div><p>Nền tảng dành cho cộng đồng nhiếp ảnh film Việt Nam.</p><span>© 2026 FilmLab</span></footer>

      {booking && <div className="modal-backdrop" onMouseDown={() => setBooking(null)}>
        <div className="modal" onMouseDown={e => e.stopPropagation()}>
          <button className="modal-close" onClick={() => setBooking(null)}><Icon name="close"/></button>
          {!confirmed ? <>
            <span className="kicker">XÁC NHẬN ĐẶT LỊCH</span><h2>{booking.name}</h2><p className="modal-place"><Icon name="map" size={16}/> {booking.place}</p>
            <div className="booking-grid"><label>Ngày sử dụng<input type="date" defaultValue="2026-04-08"/></label><label>Khung giờ<select><option>09:00 — 11:00</option><option>13:00 — 15:00</option><option>18:00 — 20:00</option></select></label></div>
            <div className="resource"><span><Icon name="camera"/> Máy scan film Noritsu</span><small>Sẵn sàng</small></div>
            <div className="total"><span>Tạm tính (2 giờ)</span><strong>{booking.price * 2}.000đ</strong></div>
            <button className="confirm" onClick={() => {
              const key = `filmlab-customer-bookings-${user.email}`;
              const current = loadAdminData<BookingItem[]>(key, []);
              const newBooking: BookingItem = { id: `FL-${Date.now().toString().slice(-4)}`, customer: user.name, space: booking.name, time: "09:00 – 11:00", status: "Chờ duyệt" };
              localStorage.setItem(key, JSON.stringify([newBooking, ...current]));
              setConfirmed(true);
            }}>Xác nhận giữ chỗ</button>
            <small className="safe"><Icon name="clock" size={14}/> Tài nguyên được khóa ngay sau khi xác nhận</small>
          </> : <div className="success"><div>✓</div><h2>Đặt lịch thành công!</h2><p>Mã đặt chỗ <b>FL-2408</b> đã được tạo. Hẹn gặp bạn tại {booking.name}.</p><button className="confirm" onClick={() => setBooking(null)}>Hoàn tất</button></div>}
        </div>
      </div>}
      <Chatbot open={chatOpen} onOpenChange={setChatOpen}/>
      {profileOpen && <ProfileManager user={user} onClose={() => setProfileOpen(false)} onSave={profile => { const nextUser = {...user, name:profile.name, email:profile.email}; setUser(nextUser); localStorage.setItem("filmlab-user", JSON.stringify(nextUser)); }}/>}
    </div>
  );
}
